/**
 * 
 */
package com.pavuluri;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Joiner;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.common.graph.EndpointPair;
import com.google.common.graph.GraphBuilder;
import com.google.common.graph.MutableGraph;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GraphExample {
	
	private static final Logger logger = LoggerFactory.getLogger(GraphExample.class);

	public static List<String> readFileInList(File file) throws IOException {
		logger.warn("reading the data file using file name provided, make sure file available."+ file.getPath());
		logger.trace("inside readFileInList method");
		List<String> lines = Collections.emptyList();
		List<String> lines1 = new ArrayList<>();
		try {
			if (!file.isFile()) {
				logger.error("File not found");
				throw new FileNotFoundException("File not found, check the path provided." + Paths.get(file.getName()));
			}			 		
			
			lines = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
			
			Predicate<String> p = x -> x.contains("#");
			for (String line : lines) {
				if (!p.test(line)) {
					lines1.add(line);
				}
			}
		}

		catch (IOException e) {
			logger.error("exception occured"+e.getMessage());
			throw new IOException(e);
		}
		return lines1;
	}

	public static void main(String[] args) throws IOException {
		
		logger.info("Starting the program");
		
		List<String> listOfNodes = readFileInList(new GraphExample().getFileFromResources("p2p-Gnutella08.txt"));

		Iterator<String> itr = listOfNodes.iterator();
		
		MutableGraph<Integer> originalGraph = createGraphUsingNodeList(itr); 
		
		createJsonFile(originalGraph);		

		joinerOnNodesOfGraph(originalGraph);
		
		logger.info("End of program");

	}

	public File getFileFromResources(String fileName) {
		logger.trace("inside getFileFromResources method");
		ClassLoader classLoader = getClass().getClassLoader();

        URL resource = classLoader.getResource(fileName);
        if (resource == null) {
            throw new IllegalArgumentException("file is not found!");
        } else {
            return new File(resource.getFile());
        }
	}

	public static void joinerOnNodesOfGraph(MutableGraph<Integer> originalGraph) {
		logger.trace("inside joinerOnNodesOfGraph method");
		Joiner joiner = Joiner.on("; ").skipNulls();

		System.out.println("Edges:-");
		for (EndpointPair<Integer> edge : originalGraph.edges()) {
			//System.out.println(joiner.join(edge.nodeU(), edge.nodeV()));
		}		
	}

	public static void createJsonFile(MutableGraph<Integer> originalGraph) {
		logger.trace("inside createJsonFile method");
		SerializableGraph serializableGraph = new SerializableGraph();
		serializableGraph.setEdges(originalGraph.edges());
		serializableGraph.setNodes(originalGraph.nodes());

		logger.trace(serializableGraph.toString());
		File jsonFile = new File("Output.json");

		try (Writer writer = new FileWriter(jsonFile.getPath())) {
			Gson gson = new GsonBuilder().create();
			gson.toJson(serializableGraph, writer);
		} catch (IOException e) {
			e.printStackTrace();
		}

		logger.info(jsonFile.getAbsolutePath() + " is created successfully.");
		
	}

	public static MutableGraph<Integer> createGraphUsingNodeList(Iterator<String> itr) {
		logger.trace("inside createGraphUsingNodeList method");
		MutableGraph<Integer> originalGraph = GraphBuilder.directed().expectedNodeCount(6500).build();
		while (itr.hasNext()) {
			String str = itr.next();
			String[] splited = str.split("\\s+");
		
			Optional<Integer> value1 = Optional.fromNullable(Integer.parseInt(splited[0]));
			Optional<Integer> value2 = Optional.fromNullable(Integer.parseInt(splited[1]));
		
			originalGraph.putEdge(checkValue(value1), checkValue(value2));
		}
		
		return originalGraph;
	}

	public static Integer checkValue(Optional<Integer> input) {
		logger.trace("inside checkValue method");
		Integer value = input.get();
		Preconditions.checkArgument(value >= 0, "Illegal Argument passed: Negative value %s.", value);
		return value;
	}

}
