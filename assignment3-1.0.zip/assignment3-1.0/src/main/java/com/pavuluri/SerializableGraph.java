/**
 * 
 */
package com.pavuluri;

import java.io.Serializable;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.common.graph.EndpointPair;

public class SerializableGraph implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	private Set<Integer> nodes;
	
	private Set<EndpointPair<Integer>> edges;

	public Set<Integer> getNodes() {
		return nodes;
	}

	public void setNodes(Set<Integer> nodes) {
		this.nodes = nodes;
	}

	public Set<EndpointPair<Integer>> getEdges() {
		return edges;
	}

	public void setEdges(Set<EndpointPair<Integer>> edges) {
		this.edges = edges;
	}
	
	@Override
    public String toString() {

        return MoreObjects.toStringHelper(this)
            .add("nodes ", "edges")
            .toString();

    }

}
