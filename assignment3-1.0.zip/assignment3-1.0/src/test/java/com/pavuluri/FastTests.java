/**
 * 
 */
package com.pavuluri;

public interface FastTests {

}
