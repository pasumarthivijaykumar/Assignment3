/**
 * 
 */
package com.pavuluri;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runners.MethodSorters;

import com.google.common.base.Optional;
import com.google.common.graph.MutableGraph;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GraphExampleTest {
	
	private static GraphExample graphExample;
	private static File resourceFile;

	@BeforeClass
	public static void setup() {
		graphExample = new GraphExample();
		resourceFile = graphExample.getFileFromResources("p2p-Gnutella08.txt");		
	}
		
	@Test
	@Category(FastTests.class)
	public void firstTestReadFileInList() throws IOException {
		System.out.println("fast");
		if(!getListOfNodes().isEmpty()) {
			assertTrue(true);
		}else {
			assertTrue(false);
		}
	}
	
	@Test
	@Category(SlowTests.class)
	public void secondTestCreateGraphUsingNodeList() throws IOException {
		System.out.println("slow");
		if(getGraph().edges().isEmpty()) {
			assertTrue(false);
		}else {
			assertTrue(true);
		}
	}
	
	@Test
	@Category(FastTests.class)
	public void thirdTestCreateJsonFile() throws IOException {
		GraphExample.createJsonFile(getGraph());
		File jsonFile = new File("Output.json");
		if(jsonFile.exists()) {
			assertTrue(true);
		}else {
			assertTrue(false);
		}
	}
	
	@Test
	@Category(SlowTests.class)
	public void fourthTestJoinerOnNodesOfGraph() throws IOException {
		GraphExample.joinerOnNodesOfGraph(getGraph());
		assertTrue(true);
	}
	
	@Test
	@Category(FastTests.class)
	public void fifthTestCheckValue() {
		Optional<Integer> value1 = Optional.fromNullable(Integer.parseInt("1"));
		GraphExample.checkValue(value1);
	}
	
	@Test
	@Category(SlowTests.class)
	public void sixthTestMain() throws IOException {
		GraphExample.main(new String[] {""});
		assertTrue(true);
	}
	
	
	@AfterClass
	public static void clear() {
		graphExample = null;
	}
	
	private List<String> getListOfNodes() throws IOException{
		return GraphExample.readFileInList(resourceFile);
	}
	
	private MutableGraph<Integer> getGraph() throws IOException{
		Iterator<String> itr = getListOfNodes().iterator();
		return GraphExample.createGraphUsingNodeList(itr);
	}	
	
}
