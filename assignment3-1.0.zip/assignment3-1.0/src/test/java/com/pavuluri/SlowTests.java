package com.pavuluri;

public interface SlowTests {

}
