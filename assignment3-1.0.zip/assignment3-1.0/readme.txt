Optional class -- GraphExample.java - line no: 60, 61

Preconditions -- GraphExample.java - line no: 93

toString enhancement -- SerializableGraph.java -- line no: 46

Joiner -- GraphExample.java -- line no: 82, 86

tried using premities, but for my used data usage is not accepted.